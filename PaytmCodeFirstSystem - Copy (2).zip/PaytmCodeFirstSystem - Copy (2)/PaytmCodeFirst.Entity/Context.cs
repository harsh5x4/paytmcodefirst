﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace PaytmCodeFirst.Entity
{
    public class Context1:DbContext
    {
        public Context1():base()
        {

        }
        public  DbSet<Consumer_123> Consumer_123{ get; set; }
        public  DbSet<Recharge_123> Recharge_123 { get; set; }
    }
    
}
