﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PaytmCodeFirst.Entity
{
    public class Consumer_123
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long Mob_No { get; set; }
        public string Name { get; set; }
        public string Region { get; set; }

        public ICollection<Recharge_123> Recharge_123 { get; set; }

    }
}
