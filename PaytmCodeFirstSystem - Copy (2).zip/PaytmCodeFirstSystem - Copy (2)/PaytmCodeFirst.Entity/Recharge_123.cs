﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PaytmCodeFirst.Entity
{
    public class Recharge_123
    {
        [Key]
        public int RechargeId { get; set; }
        public double Amount { get; set; }
        public int Validity { get; set; }
        public string Data { get; set; }
        public string Talktime { get; set; }
        public DateTime RechargeOn { get; set; }
        public DateTime ValidTillDate { get; set; }
        
        
        public long Mob_No { get; set; }
    }
}
