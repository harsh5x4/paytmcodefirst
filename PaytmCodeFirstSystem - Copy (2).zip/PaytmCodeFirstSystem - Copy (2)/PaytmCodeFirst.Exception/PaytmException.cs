﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaytmCodeFirst.Exception
{
    public class PaytmException:ApplicationException
    {
        public PaytmException()
            : base()
        {

        }

        public PaytmException(string message)
            : base(message)
        {

        }
    }
}
