﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PaytmCodeFirst.Entity;
using PaytmCodeFirst.Exception;
using PaytmCodeFirst.DAL;
using System.Text.RegularExpressions;

namespace PaytmCodeFirst.BL
{
    public class PaytmValidations
    {
        private static bool PaytmValidation(Recharge_123 stud)
        {
            bool studValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.Mob_No.ToString() == string.Empty)
                {
                    message.Append("Mobile no should be provided\n");
                    studValidated = false;
                }




                else if (!Regex.IsMatch(stud.Mob_No.ToString(), "[0-9]{10}"))
                {
                    message.Append("Mobile no should have 10 digits");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new PaytmException(message.ToString());
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }


        public static int AddRecharge(Recharge_123 stud)
        {
            int records = 0;

            try
            {
                if (PaytmValidation(stud))
                {
                    records = PaytmOperations.AddRecharge(stud);
                }
                else
                    throw new PaytmException("Please provide valid information");
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static Consumer_123 SearchConsumer(Int64 scode)
        {
            Consumer_123 stud = null;

            try
            {
                stud = PaytmOperations.SearchConsumer(scode);
                if(stud==null)
                {
                    throw new PaytmException("Invalid user");
                }
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

    
    }
}
